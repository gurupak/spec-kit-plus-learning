# Spec-Kit Mastery Guide for Agentic AI Engineers

## 🎯 What You'll Master

By the end of this guide, you'll be able to:
- Use Spec-Driven Development (SDD) to build AI applications systematically
- Leverage AI coding agents to generate production-ready code from specifications
- Create multi-agent systems using spec-kit as your development framework
- Build FastAPI backends and Next.js frontends with SDD methodology
- Integrate spec-kit with your existing LangGraph, CrewAI, and OpenAI Agents SDK projects

---

## 📚 Part 1: Core Concepts

### What is Spec-Driven Development?

**Traditional Approach:**
```
Vibe-coding → Write code → Hope it works → Fix bugs → Repeat
```

**Spec-Driven Development:**
```
Define WHAT & WHY → AI generates HOW → Structured implementation → Predictable outcomes
```

### Key Paradigm Shift

| Traditional | Spec-Driven |
|------------|-------------|
| Code is king | Specifications are executable |
| Specs are discarded after coding | Specs directly generate implementations |
| One-shot prompts to AI | Multi-step refinement process |
| Vibe-coding | Intent-driven development |

### Why This Matters for AI Engineers

When building agentic systems, you need:
1. **Clear boundaries** between agents
2. **Documented workflows** for multi-agent coordination
3. **Reproducible patterns** for RAG, function calling, and tool use
4. **Version-controlled evolution** of agent behaviors

Spec-kit provides the structure to achieve all of this.

---

## 🛠️ Part 2: Installation & Setup

### Prerequisites Check

```bash
# 1. Install uv (Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh

# 2. Verify Python 3.11+
python --version

# 3. Verify Git
git --version

# 4. Install Claude Code (if using Claude)
# Visit: https://www.anthropic.com/claude-code
```

### Installation Methods

#### Method 1: Global Installation (Recommended)

```bash
# Install once, use everywhere
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# Verify installation
specify check

# Later, to upgrade:
uv tool install specify-cli --force --from git+https://github.com/github/spec-kit.git
```

**Benefits:**
- Always available in PATH
- No shell aliases needed
- Easy to manage with `uv tool list`, `uv tool upgrade`, `uv tool uninstall`

#### Method 2: Direct Execution (No Installation)

```bash
# Run without installing
uvx --from git+https://github.com/github/spec-kit.git specify init <PROJECT_NAME>
```

---

## 🚀 Part 3: Your First Spec-Kit Project

### Step 1: Initialize Project

```bash
# Basic initialization
specify init my-ai-agent-project

# With specific AI agent (Claude Code recommended)
specify init my-ai-agent-project --ai claude

# Initialize in current directory
specify init . --ai claude
# or
specify init --here --ai claude

# Force merge into non-empty directory
specify init . --force --ai claude

# Skip git initialization (if managing separately)
specify init my-ai-agent-project --ai claude --no-git

# With debug output for troubleshooting
specify init my-ai-agent-project --ai claude --debug

# For corporate environments with GitHub token
specify init my-ai-agent-project --ai claude --github-token ghp_your_token_here
```

### Step 2: Launch Your AI Agent

```bash
cd my-ai-agent-project

# If using Claude Code
claude
```

### Step 3: Verify Setup

You should see these slash commands available:
- `/speckit.constitution`
- `/speckit.specify`
- `/speckit.clarify`
- `/speckit.plan`
- `/speckit.tasks`
- `/speckit.implement`
- `/speckit.analyze`
- `/speckit.checklist`

---

## 📋 Part 4: The Spec-Driven Development Workflow

### The 6-Step Process

```mermaid
graph LR
    A[Constitution] --> B[Specify]
    B --> C[Clarify]
    C --> D[Plan]
    D --> E[Tasks]
    E --> F[Implement]
```

### Step 1: Constitution - Define Your Principles

**Purpose:** Set project governance and decision-making guidelines

**Command:**
```
/speckit.constitution Create principles focused on code quality, testing standards, user experience consistency, and performance requirements
```

**Example for AI Projects:**
```
/speckit.constitution Create principles for an agentic AI system:
- All agent interactions must be logged with structured metadata
- Use FastAPI with SQLModel for backend consistency
- Next.js App Router with middleware for authentication
- All LLM calls must have retry logic with exponential backoff
- Use Pydantic v2 for all data validation
- Follow OpenAI Agents SDK patterns for agent orchestration
- Testing: 80% coverage minimum, integration tests for all agent workflows
- Performance: Agent response time <2s for 95th percentile
```

**Output:** `.specify/memory/constitution.md`

### Step 2: Specify - Define WHAT You Want

**Purpose:** Create functional specifications (focus on WHAT & WHY, not HOW)

**Command:**
```
/speckit.specify [Your requirements]
```

**Example for AI RAG System:**
```
/speckit.specify Build a multi-tenant RAG system called "SmartDocs" that:

CORE FEATURES:
- Users can upload PDF documents to their workspace
- System automatically chunks documents and generates embeddings
- Users can query their documents using natural language
- Each query triggers a multi-agent workflow:
  * Retrieval Agent: Finds relevant chunks using semantic search
  * Synthesis Agent: Combines chunks into coherent response
  * Verification Agent: Fact-checks against source documents
- Support multiple embedding models (OpenAI, Cohere)
- Track query history and agent decision-making

USER STORIES:
- As a user, I can upload PDFs and see processing status
- As a user, I can ask questions and see which agents are working
- As a user, I can view citations linking to source document pages
- As an admin, I can monitor agent performance and costs

CONSTRAINTS:
- Must handle PDFs up to 50MB
- Support 100 concurrent users
- Agent workflow must complete in <10 seconds
- All data encrypted at rest
```

**Output:** `.specify/specs/001-smartdocs/spec.md`

### Step 3: Clarify - Fill Knowledge Gaps

**Purpose:** Structured Q&A to resolve ambiguities before implementation

**Command:**
```
/speckit.clarify
```

**What Happens:**
- Agent asks targeted questions about underspecified areas
- Questions are sequential and coverage-based
- Answers are recorded in a Clarifications section
- Reduces rework downstream

**Example Follow-up:**
```
For each workspace, users should have:
- Maximum 10GB storage
- Rate limit of 100 queries/day
- Ability to share documents with team members
- Audit logs of all access events
```

**Validation:**
```
Read the review and acceptance checklist, and check off each item if the feature spec meets the criteria. Leave it empty if it does not.
```

### Step 4: Plan - Define HOW to Build It

**Purpose:** Technical architecture and implementation approach

**Command:**
```
/speckit.plan [Your tech stack and architecture]
```

**Example for AI Project:**
```
/speckit.plan Architecture:

BACKEND:
- FastAPI with SQLModel for database models
- PostgreSQL with pgvector extension for vector storage
- Celery with Redis for async document processing
- OpenAI Agents SDK for agent orchestration
- LangChain for embedding generation and retrieval
- Pydantic v2 for request/response validation

FRONTEND:
- Next.js 14 with App Router
- Middleware for JWT authentication
- shadcn/ui for components
- TanStack Query for data fetching
- WebSocket for real-time agent progress updates

AI INFRASTRUCTURE:
- OpenAI GPT-4 for Synthesis Agent
- Claude Sonnet for Verification Agent
- OpenAI text-embedding-3-large for embeddings
- Pinecone for vector database (alternative to pgvector)

DEPLOYMENT:
- Docker containers
- AWS ECS for container orchestration
- S3 for document storage
- CloudWatch for monitoring

ARCHITECTURE PATTERNS:
- Clean Architecture with dependency injection
- Repository pattern for data access
- Agent coordination using LangGraph state machines
- Event-driven document processing
```

**Output Files:**
- `plan.md` - Implementation plan
- `data-model.md` - Database schema
- `contracts/api-spec.json` - API contracts
- `research.md` - Tech stack research
- `quickstart.md` - Developer setup guide

**Validation Steps:**
```bash
# Ask agent to research rapidly changing tech
I want you to research specific versions of:
- FastAPI latest stable release
- SQLModel compatibility with Pydantic v2
- OpenAI Agents SDK current best practices
- LangGraph latest patterns for multi-agent coordination

# Audit the plan
Now audit the implementation plan for:
- Obvious missing steps
- Over-engineered components
- Misalignment with constitution
- Missing error handling patterns
```

### Step 5: Tasks - Break Down into Actions

**Purpose:** Generate ordered, executable task list

**Command:**
```
/speckit.tasks
```

**Output:** `tasks.md` with:
- Tasks organized by user story
- Dependency management
- Parallel execution markers `[P]`
- Exact file paths for implementation
- Test-first approach (if requested)
- Checkpoint validations

**Example Task Structure:**
```markdown
## Phase 1: Document Upload (User Story #1)

### Database & Models
1. [Sequential] Create document model in models/document.py
2. [Sequential] Create embedding model in models/embedding.py
3. [P] Write tests for document model
4. [P] Write tests for embedding model

### API Layer
5. [Sequential] Implement POST /documents endpoint
6. [Sequential] Implement GET /documents endpoint
7. [Sequential] Add file validation middleware
8. [P] Write integration tests for upload flow

### Processing Pipeline
9. [Sequential] Create Celery task for PDF processing
10. [P] Implement chunking service
11. [P] Implement embedding generation
12. [P] Write tests for processing pipeline

**Checkpoint:** User can upload PDF and see processing status
```

### Step 6: Implement - Execute the Plan

**Purpose:** AI agent executes all tasks systematically

**Command:**
```
/speckit.implement
```

**What Happens:**
- Validates prerequisites (constitution, spec, plan, tasks)
- Parses task breakdown
- Executes in order (respects dependencies)
- Handles parallel tasks
- Follows TDD if defined
- Runs local CLI commands (npm, pip, etc.)

**Monitoring:**
- Progress updates per task
- Error handling and reporting
- Test execution results

**Post-Implementation:**
```bash
# Test the application
# Check browser console for frontend errors
# Review API logs for backend issues

# If errors occur, copy-paste to AI agent:
I'm seeing this error in the browser console:
[Error details]

# Agent will fix and re-implement
```

---

## 🎨 Part 5: Advanced Workflows

### Scenario 1: Building OpenAI Agents SDK Application

```bash
# Initialize
specify init openai-agents-app --ai claude

# Constitution
/speckit.constitution Create principles for OpenAI Agents SDK:
- Use streaming for all agent responses
- Implement function calling for external APIs
- Use Assistant API with vector stores
- Handle rate limits gracefully
- Structured outputs with Pydantic
- Comprehensive error logging
```

### Scenario 2: Building Multi-Agent LangGraph System

```bash
# Specify
/speckit.specify Build a customer support automation system with three agents:

1. Classifier Agent: Categorizes incoming tickets (technical, billing, general)
2. Resolution Agent: Attempts to resolve based on knowledge base
3. Escalation Agent: Routes to human if needed

Use LangGraph for state management and agent coordination.
Each agent should have:
- Tool access (search KB, update ticket, notify human)
- Memory of conversation history
- Configurable confidence thresholds
```

### Scenario 3: Building n8n Workflow Integration

```bash
# Plan
/speckit.plan Architecture:
- FastAPI backend exposes webhook endpoints
- n8n workflows trigger on events
- Agent system processes tasks from n8n
- Results sent back via webhook
- Use n8n's REST API for workflow management
```

### Scenario 4: Non-Git Projects

```bash
# Set feature override
export SPECIFY_FEATURE=001-my-feature

# Then use normal commands
/speckit.plan
/speckit.tasks
/speckit.implement
```

---

## 🔧 Part 6: Supported AI Agents

| Agent | Support | Notes |
|-------|---------|-------|
| Claude Code | ✅ | Recommended, full support |
| Cursor | ✅ | Full support |
| Windsurf | ✅ | Full support |
| Gemini CLI | ✅ | Full support |
| GitHub Copilot | ⚠️ | Limited (no custom arguments) |
| Roo Code | ✅ | Full support |
| Others | See docs | Many more supported |

**Installation Examples:**
```bash
# Claude Code
specify init project --ai claude

# Cursor
specify init project --ai cursor-agent

# Windsurf
specify init project --ai windsurf

# Gemini
specify init project --ai gemini
```

---

## 📊 Part 7: Project Structure After Setup

```
my-ai-project/
├── .specify/
│   ├── memory/
│   │   └── constitution.md          # Project principles
│   ├── scripts/
│   │   ├── check-prerequisites.sh
│   │   ├── common.sh
│   │   ├── create-new-feature.sh
│   │   ├── setup-plan.sh
│   │   └── update-claude-md.sh
│   ├── specs/
│   │   └── 001-feature-name/
│   │       ├── spec.md              # Requirements
│   │       ├── plan.md              # Tech plan
│   │       ├── tasks.md             # Task breakdown
│   │       ├── data-model.md        # Database schema
│   │       ├── research.md          # Tech research
│   │       ├── quickstart.md        # Dev setup
│   │       └── contracts/
│   │           └── api-spec.json    # API contracts
│   └── templates/
│       ├── CLAUDE-template.md
│       ├── spec-template.md
│       ├── plan-template.md
│       └── tasks-template.md
├── src/                              # Your code here
├── tests/                            # Your tests here
└── CLAUDE.md                         # Agent context file
```

---

## 🎯 Part 8: Best Practices for AI Projects

### 1. Constitution Design

```
/speckit.constitution For AI agent systems:

AGENT DESIGN:
- Single Responsibility: Each agent has one clear purpose
- Composability: Agents can be combined in workflows
- Observability: All decisions logged with reasoning
- Testability: Agents have deterministic test modes

CODE STANDARDS:
- Type hints everywhere (Python) / TypeScript (Node.js)
- Pydantic for all data models
- Async/await for all I/O operations
- Structured logging with correlation IDs

TESTING:
- Unit tests: Pure functions and model validation
- Integration tests: Agent workflows end-to-end
- Load tests: Simulate concurrent agent executions
- LLM mocking: Use recorded responses for deterministic tests

PERFORMANCE:
- Cache embeddings aggressively
- Stream LLM responses to users
- Background processing for long-running tasks
- Circuit breakers for external API calls

SECURITY:
- Never log API keys or PII
- Validate all user inputs with Pydantic
- Rate limit per user/tenant
- Audit log all agent actions
```

### 2. Specification Tips

**DO:**
- Focus on user outcomes, not implementation
- Include concrete examples of inputs/outputs
- Define edge cases explicitly
- Specify error handling requirements
- Include performance constraints

**DON'T:**
- Specify exact libraries (save for plan phase)
- Implement in the spec (no code)
- Leave user stories ambiguous
- Skip acceptance criteria

### 3. Planning for AI Systems

**Research Areas:**
```
Ask agent to research:
1. Current OpenAI model capabilities and limits
2. Best practices for prompt engineering in 2024
3. Vector database comparison (Pinecone vs pgvector)
4. LangGraph vs CrewAI for multi-agent orchestration
5. Streaming patterns for real-time agent updates
```

**Common Pitfalls:**
- Over-engineering: Agent doesn't need a custom framework
- Under-specifying: Forgetting retry logic, rate limits
- Ignoring costs: Not planning for token usage monitoring

### 4. Task Breakdown Patterns

For agent systems, typical task phases:
1. **Data Layer**: Models, database, migrations
2. **Agent Core**: Prompts, tools, coordination logic
3. **API Layer**: Endpoints, WebSockets, webhooks
4. **UI Layer**: Components, state management, real-time updates
5. **Testing**: Unit, integration, end-to-end
6. **Deployment**: Docker, environment configs, monitoring

---

## 🧩 Part 9: Integration Examples

### With OpenAI Agents SDK

```python
# In your spec:
/speckit.specify Build an assistant that:
- Uses OpenAI Assistant API with file search
- Has function calling for external APIs
- Streams responses to frontend
- Maintains conversation threads per user
- Stores thread metadata in PostgreSQL

# In your plan:
/speckit.plan Use OpenAI Agents SDK:
- Create Assistant with tools: [file_search, api_caller]
- Use ThreadRun for each conversation
- Stream events to WebSocket
- Store thread_id in user session
- Implement cleanup job for old threads
```

### With LangGraph

```python
# In your spec:
/speckit.specify Build a research agent system:
- Planning Agent: Creates research plan
- Search Agent: Gathers information
- Synthesis Agent: Writes final report
- Use LangGraph for state management
- Support checkpointing to resume interrupted workflows

# In your plan:
/speckit.plan LangGraph architecture:
- Define StateGraph with nodes for each agent
- Use MemorySaver for checkpointing
- Implement conditional edges based on agent outputs
- Use subgraphs for complex agent workflows
- Expose graph as FastAPI endpoint
```

### With CrewAI

```python
# In your spec:
/speckit.specify Build a content creation crew:
- Researcher: Gathers facts
- Writer: Drafts content
- Editor: Reviews and improves
- SEO Specialist: Optimizes for search
- All agents collaborate on a shared task

# In your plan:
/speckit.plan CrewAI setup:
- Define roles, goals, backstories for each agent
- Create tasks with dependencies
- Use sequential process for workflow
- Implement custom tools for each agent
- Stream progress updates to frontend
```

### With n8n

```bash
# Constitution
/speckit.constitution For n8n integration:
- All workflows triggered via webhook
- Return 200 immediately, process async
- Send results via callback webhook
- Store workflow execution IDs
- Handle n8n failures gracefully

# Specify
/speckit.specify Build n8n-powered document processing:
- User uploads document via API
- API triggers n8n workflow via webhook
- n8n orchestrates: extraction → validation → storage
- n8n calls back to API with results
- User sees real-time status updates

# Plan
/speckit.plan Integration:
- FastAPI webhook endpoint for n8n triggers
- Celery task to monitor n8n execution status
- n8n workflow with error handling
- PostgreSQL to store execution metadata
- WebSocket to push updates to frontend
```

---

## 🐛 Part 10: Troubleshooting

### Issue: Git Authentication on Linux

```bash
# Install Git Credential Manager
wget https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.6.1/gcm-linux_amd64.2.6.1.deb
sudo dpkg -i gcm-linux_amd64.2.6.1.deb
git config --global credential.helper manager
rm gcm-linux_amd64.2.6.1.deb
```

### Issue: Agent Not Finding Commands

```bash
# Verify setup
specify check

# Re-initialize with force
specify init . --force --ai claude

# Check CLAUDE.md exists
ls -la CLAUDE.md
```

### Issue: Agent Over-Engineering

```bash
# During plan phase, ask:
Review the plan and identify any over-engineered components.
For each one, explain why it's over-engineered and propose a simpler alternative.
Remember our constitution emphasizes pragmatism over perfection.
```

### Issue: Implementation Fails

```bash
# Check prerequisites
Make sure you've installed all required tools:
- Node.js for Next.js projects
- Python 3.11+ for FastAPI
- Docker for containerized apps

# Enable debug mode
specify init project --ai claude --debug
```

### Issue: Tasks Not in Right Order

```bash
# After /speckit.tasks:
Review the task dependencies. Ensure:
1. Database models before API endpoints
2. API endpoints before frontend components
3. Tests written before implementation (TDD)
4. Migrations before data seeding

Reorder tasks if needed and update tasks.md
```

---

## 📈 Part 11: Real-World Project: Agentic RAG System

### Complete Workflow Example

```bash
# 1. Initialize
specify init rag-agent-system --ai claude
cd rag-agent-system
claude

# 2. Constitution
/speckit.constitution Create principles for production RAG system:
- FastAPI with SQLModel for all database models
- Next.js 14 App Router with TypeScript strict mode
- All agent interactions use OpenAI Agents SDK
- Vector storage with Pinecone for scale
- Redis for caching and job queues
- Comprehensive logging with structured metadata
- 90% test coverage for critical paths
- Error handling with retry mechanisms
- Real-time updates via WebSockets
- API rate limiting per tenant

# 3. Specify
/speckit.specify Build AgentRAG - Enterprise RAG System:

CORE FEATURES:
- Multi-tenant document management (PDF, DOCX, TXT)
- Three-agent processing pipeline:
  * Ingestion Agent: Chunks, embeds, indexes documents
  * Query Agent: Handles user questions with semantic search
  * Answer Agent: Synthesizes responses with citations

- Document processing:
  * Upload documents via drag-drop or API
  * Automatic extraction and preprocessing
  * Background embedding generation
  * Progress tracking with status updates

- Query system:
  * Natural language questions
  * Real-time agent activity display
  * Confidence scores for answers
  * Source citations with page numbers
  * Query history per tenant

- Admin dashboard:
  * Monitor agent performance
  * View cost metrics (tokens, API calls)
  * Manage embedding models
  * Configure retrieval parameters

USER STORIES:
1. As a user, I upload a 20-page research paper and see processing progress
2. As a user, I ask "What are the key findings?" and see which agent is working
3. As a user, I click citations to jump to source document pages
4. As an admin, I view daily token usage and cost breakdown
5. As a user, I adjust retrieval settings (top_k, similarity threshold)

CONSTRAINTS:
- Support 1000 concurrent users
- Process documents up to 100MB
- Answer queries in <5 seconds (p95)
- Handle 10,000 documents per tenant
- Maintain 99.9% uptime

# 4. Clarify
/speckit.clarify

# Answer agent's questions like:
- Embedding model: OpenAI text-embedding-3-large
- Chunk size: 512 tokens with 50 token overlap
- Max concurrent uploads: 5 per user
- Citation format: [Doc Title, Page X]
- Cost tracking: Per-tenant, daily rollup

# 5. Validate
Read the review and acceptance checklist, and check off each item if the feature spec meets the criteria.

# 6. Plan
/speckit.plan Technical architecture:

BACKEND (FastAPI + SQLModel):
- API Layer:
  * FastAPI with async/await
  * JWT authentication middleware
  * Rate limiting with slowapi
  * CORS configuration
  * OpenAPI documentation

- Database (PostgreSQL):
  * User model (id, email, tenant_id, created_at)
  * Document model (id, tenant_id, filename, status, metadata)
  * Query model (id, user_id, question, answer, sources, created_at)
  * Usage model (id, tenant_id, tokens_used, cost, date)

- Vector Storage (Pinecone):
  * Index per tenant
  * Metadata: document_id, page_number, chunk_text
  * Dimension: 3072 (text-embedding-3-large)

- Agent System (OpenAI Agents SDK):
  * Ingestion Agent:
    - Tools: [pdf_extractor, text_chunker, embed_generator]
    - Stores embeddings in Pinecone
    - Updates document status
  * Query Agent:
    - Tools: [semantic_search, rerank]
    - Retrieves top_k chunks from Pinecone
    - Returns relevant contexts
  * Answer Agent:
    - Tools: [synthesize_answer, format_citations]
    - Uses GPT-4 with retrieved context
    - Generates structured response

- Background Jobs (Celery + Redis):
  * Document processing queue
  * Embedding generation
  * Usage rollup jobs

FRONTEND (Next.js 14):
- Pages (App Router):
  * /login - Authentication
  * /dashboard - Document management
  * /query - Question interface
  * /admin - Analytics dashboard

- Components (shadcn/ui):
  * DocumentUploader - Drag-drop with progress
  * AgentActivityPanel - Real-time agent status
  * QueryInterface - Question input with streaming
  * CitationViewer - Source document viewer

- State Management:
  * TanStack Query for data fetching
  * Zustand for global state
  * WebSocket for real-time updates

- API Integration:
  * Axios with interceptors
  * Token refresh logic
  * Error boundary handling

INFRASTRUCTURE:
- Docker Compose for local development
- AWS ECS for production deployment
- CloudWatch for monitoring
- S3 for document storage

TESTING STRATEGY:
- Backend: pytest with fixtures
  * Unit tests for models and services
  * Integration tests for API endpoints
  * E2E tests for agent workflows

- Frontend: Vitest + React Testing Library
  * Component tests
  * Integration tests with MSW
  * E2E tests with Playwright

# 7. Research validation
Go through the implementation plan and identify areas needing research:
- OpenAI Agents SDK streaming patterns
- Pinecone serverless vs pod-based for our scale
- FastAPI WebSocket best practices
- SQLModel migrations with Alembic
- Next.js App Router authentication patterns

For each area, spawn parallel research tasks with web search.

# 8. Audit plan
Audit the implementation plan:
- Check for missing error handling
- Verify task dependencies are clear
- Ensure constitution compliance
- Look for over-engineering
- Confirm test coverage strategy

# 9. Generate tasks
/speckit.tasks

# 10. Implement
/speckit.implement

# 11. Post-implementation validation
- Test document upload flow
- Verify agent coordination
- Check WebSocket connections
- Review error logs
- Test with various document types
```

---

## 🎓 Part 12: Learning Path

### Week 1: Foundations
- [ ] Install uv and spec-kit
- [ ] Initialize first project
- [ ] Complete simple CRUD app using spec-kit
- [ ] Understand constitution → specify → plan → tasks → implement

### Week 2: AI Integration
- [ ] Build RAG system with OpenAI embeddings
- [ ] Implement LangChain integration
- [ ] Create multi-agent workflow
- [ ] Add real-time updates

### Week 3: Advanced Patterns
- [ ] Build with LangGraph state machines
- [ ] Integrate CrewAI for collaborative agents
- [ ] Implement n8n workflow orchestration
- [ ] Add monitoring and observability

### Week 4: Production Readiness
- [ ] Containerize with Docker
- [ ] Set up CI/CD pipeline
- [ ] Implement comprehensive testing
- [ ] Deploy to cloud (AWS/Azure/GCP)

---

## 🔗 Part 13: Quick Reference

### Essential Commands

```bash
# Installation
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# Initialize project
specify init <name> --ai claude

# Check setup
specify check

# Upgrade
uv tool install specify-cli --force --from git+https://github.com/github/spec-kit.git
```

### Slash Commands (in AI agent)

```
/speckit.constitution  # Project principles
/speckit.specify       # Define requirements
/speckit.clarify       # Fill knowledge gaps
/speckit.plan          # Technical architecture
/speckit.tasks         # Break into actionable tasks
/speckit.implement     # Execute implementation
/speckit.analyze       # Check consistency
/speckit.checklist     # Quality validation
```

### Environment Variables

```bash
# For non-Git repos
export SPECIFY_FEATURE=001-my-feature
```

---

## 📚 Resources

- [Official Spec-Kit Repo](https://github.com/github/spec-kit)
- [Spec-Driven Development Guide](https://github.com/github/spec-kit/blob/main/spec-driven.md)
- [Video Overview](https://www.youtube.com/watch?v=a9eR1xsfvHg)
- [Troubleshooting](https://github.com/github/spec-kit#-troubleshooting)
- [Issue Tracker](https://github.com/github/spec-kit/issues)

---

## 🎯 Next Steps

1. **Install spec-kit** following Part 2
2. **Complete first project** using Part 3
3. **Build AI system** using Part 9 examples
4. **Practice workflow** with Part 11 real-world example
5. **Ready for quiz?** Let me know when you want to test your understanding!

---

## 💡 Key Takeaways

1. **Spec-kit flips the script**: Specifications generate code, not just guide it
2. **Multi-step refinement**: Constitution → Specify → Clarify → Plan → Tasks → Implement
3. **AI agents do the heavy lifting**: You focus on WHAT, agents figure out HOW
4. **Perfect for Agentic AI**: Structured approach to building multi-agent systems
5. **Production-ready**: Not just prototypes, but maintainable production applications

---

*This guide is tailored for your background in Next.js, FastAPI, OpenAI Agents SDK, LangGraph, CrewAI, and n8n. All examples align with your tech stack preferences.*
