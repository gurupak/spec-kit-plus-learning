# Spec-Kit Hands-On Tutorial: Building an AI RAG Agent

## 🎯 What You'll Build

A production-grade RAG (Retrieval Augmented Generation) system with:
- Document upload and processing
- Multi-agent query handling
- Real-time progress updates
- FastAPI backend with SQLModel
- Next.js 14 frontend with App Router

**Time:** 30-45 minutes  
**Difficulty:** Intermediate  
**Prerequisites:** uv, Claude Code (or another AI agent)

---

## 📋 Step-by-Step Tutorial

### Step 1: Setup Environment (5 minutes)

```bash
# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install spec-kit
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# Verify
specify check

# Create project
specify init rag-assistant --ai claude
cd rag-assistant

# Launch Claude Code
claude
```

**Expected Output:**
- New directory created
- Git repository initialized
- Spec-kit files in `.specify/` folder
- Claude Code launches with `/speckit.*` commands visible

---

### Step 2: Define Project Constitution (3 minutes)

In Claude Code, run:

```
/speckit.constitution Create principles for a production RAG system:

CODE QUALITY:
- Python: Type hints everywhere, Pydantic v2 for validation
- JavaScript: TypeScript strict mode, no implicit any
- Async/await for all I/O operations
- Error handling with specific exception types

ARCHITECTURE:
- Backend: FastAPI with dependency injection
- Database: SQLModel for ORM, Alembic for migrations
- Frontend: Next.js 14 App Router, no Pages Router
- UI: shadcn/ui components exclusively

TESTING:
- Unit tests: 80% minimum coverage
- Integration tests: All API endpoints
- E2E tests: Critical user flows
- Mock LLM calls in tests for determinism

AI AGENTS:
- OpenAI Agents SDK for all agent logic
- Structured outputs with Pydantic schemas
- Retry logic: 3 attempts with exponential backoff
- Logging: All agent decisions with reasoning
- Streaming: All LLM responses to improve UX

PERFORMANCE:
- Document processing: <30s for 10-page PDF
- Query response: <3s (95th percentile)
- Concurrent users: Support 100+
- Caching: Redis for frequently accessed data

SECURITY:
- JWT authentication with refresh tokens
- Rate limiting: 100 requests/hour per user
- Input validation: Pydantic on all inputs
- No API keys in logs or responses
```

**What This Does:**
- Creates `.specify/memory/constitution.md`
- Agent will reference these principles in all subsequent steps
- Ensures consistency across specification, planning, and implementation

**Validation:**
Check that the file was created:
```bash
cat .specify/memory/constitution.md
```

---

### Step 3: Specify What You Want (5 minutes)

```
/speckit.specify Build RAGAssist - An intelligent document question-answering system

OVERVIEW:
RAGAssist allows users to upload documents and ask questions about them using natural language. The system uses a multi-agent architecture to retrieve relevant information and synthesize accurate answers.

CORE FEATURES:

1. Document Management
   - Users can upload PDF documents (max 50MB each)
   - System automatically extracts text and metadata
   - Documents are chunked into semantic segments
   - Each chunk is embedded using OpenAI embeddings
   - Users see real-time processing progress
   - Support for up to 100 documents per user

2. Intelligent Querying
   - Users ask questions in natural language
   - Three-agent processing pipeline:
     a) Retrieval Agent:
        - Performs semantic search across document chunks
        - Uses cosine similarity to find top 5 relevant chunks
        - Includes document metadata in results
     b) Synthesis Agent:
        - Takes retrieved chunks and user question
        - Generates comprehensive answer using GPT-4
        - Ensures answer is grounded in provided context
     c) Citation Agent:
        - Identifies which documents were used
        - Creates clickable citations with page numbers
        - Highlights relevant text in source documents

3. User Experience
   - Real-time agent activity display
   - Show which agent is currently working
   - Display confidence scores for answers
   - Expandable citations showing source text
   - Query history with ability to re-run queries

4. Administration
   - Dashboard showing usage statistics
   - Token consumption tracking per user
   - Processing status for all documents
   - Ability to re-process failed documents

USER STORIES:

Story 1: Document Upload
As a user, I want to upload a research paper so that I can ask questions about it.
- User drags PDF file into upload zone
- System shows upload progress bar
- System displays "Processing: Extracting text..." status
- System displays "Processing: Generating embeddings..." status
- System shows "Ready" when complete
- User sees document in their library

Story 2: Asking Questions
As a user, I want to ask "What is the main conclusion?" so that I can quickly understand my document.
- User types question in input field
- System shows "Retrieval Agent: Searching..." 
- System shows "Synthesis Agent: Generating answer..."
- System shows "Citation Agent: Finding sources..."
- User sees comprehensive answer with citations
- User can click citations to view source text

Story 3: Viewing Sources
As a user, I want to see which parts of my document were used so that I can verify the answer.
- User clicks on [Source: Paper.pdf, p.3]
- Modal opens showing document page 3
- Relevant text is highlighted in yellow
- User can read full context around highlighted text
- User can close modal and continue

Story 4: Query History
As a user, I want to see my previous questions so that I can reference earlier answers.
- User clicks "History" tab
- System shows list of all previous queries with timestamps
- Each query shows question, answer, and citations
- User can re-run any previous query
- User can delete queries from history

Story 5: Admin Monitoring
As an admin, I want to see token usage so that I can manage costs.
- Admin opens dashboard
- System shows total tokens used today
- System shows breakdown by user
- System shows cost estimate
- System shows average query response time

CONSTRAINTS:
- Document processing must complete in <2 minutes for 10-page PDF
- Query response time must be <5 seconds (95th percentile)
- Support 50 concurrent users
- Maximum 100 documents per user
- Each document limited to 50MB
- Retain query history for 30 days
- System available 99.5% of time

ACCEPTANCE CRITERIA:
- User can upload PDF and see it become "Ready"
- User can ask question and receive answer with citations
- Citations link to correct page and highlight correct text
- All agent activity is visible to user in real-time
- Admin can view usage dashboard
- System handles errors gracefully (e.g., corrupt PDF)
- Rate limiting prevents abuse
```

**What This Does:**
- Creates `.specify/specs/001-ragassist/spec.md`
- Documents all requirements without specifying HOW to build it
- Provides foundation for next steps

**Validation:**
```bash
cat .specify/specs/001-ragassist/spec.md
```

---

### Step 4: Clarify Underspecified Areas (5 minutes)

```
/speckit.clarify
```

**What Happens:**
Agent asks targeted questions about ambiguous areas. Answer them:

**Example Q&A:**

**Q:** What embedding model should be used? What dimensions?  
**A:** Use OpenAI text-embedding-3-large with 3072 dimensions

**Q:** How should chunks be sized? What overlap?  
**A:** 512 tokens per chunk with 50 token overlap

**Q:** What vector database for storing embeddings?  
**A:** Use PostgreSQL with pgvector extension (simpler for small scale)

**Q:** What happens if document processing fails?  
**A:** Mark document as "Failed" with error message. User can retry processing. Log error details for debugging.

**Q:** How should concurrent document uploads be handled?  
**A:** Queue documents in Celery. Process 3 documents in parallel maximum. Others wait in queue.

**Q:** What authentication method?  
**A:** JWT tokens with 1-hour expiration and 7-day refresh tokens

**Q:** Citation format?  
**A:** [Document Name, Page X]. Clicking opens modal with that page.

**After answering, validate:**
```
Read the review and acceptance checklist, and check off each item in the checklist if the feature spec meets the criteria. Leave it empty if it does not.
```

**What This Does:**
- Adds "Clarifications" section to spec.md
- Reduces rework in later phases
- Ensures agent has all information needed

---

### Step 5: Create Technical Plan (8 minutes)

```
/speckit.plan Technical Architecture:

BACKEND STACK:

1. API Framework
   - FastAPI 0.115+ with async/await
   - Pydantic v2 for request/response models
   - SQLModel for database ORM
   - Alembic for database migrations
   - Python 3.11+

2. Database
   - PostgreSQL 15 with pgvector extension
   - Tables:
     * users (id, email, password_hash, created_at)
     * documents (id, user_id, filename, status, file_path, page_count, created_at)
     * chunks (id, document_id, content, embedding, page_number, chunk_index)
     * queries (id, user_id, question, answer, sources, created_at)
     * usage (id, user_id, tokens_used, cost, timestamp)

3. Vector Storage
   - pgvector extension for PostgreSQL
   - Store embeddings as vector(3072)
   - Create index: CREATE INDEX ON chunks USING ivfflat (embedding vector_cosine_ops)

4. Background Jobs
   - Celery with Redis broker
   - Tasks:
     * process_document(document_id)
     * generate_embeddings(document_id)
     * cleanup_old_queries() - runs daily

5. Agent System (OpenAI Agents SDK)
   
   Retrieval Agent:
   - Function: semantic_search(query: str, top_k: int) -> List[Chunk]
   - Implementation: Query pgvector with cosine similarity
   - Returns: Top 5 chunks with scores
   
   Synthesis Agent:
   - Function: generate_answer(question: str, context: List[str]) -> str
   - Model: GPT-4-turbo with streaming
   - System prompt: "Answer based only on provided context. Be concise."
   - Temperature: 0.2 (more deterministic)
   
   Citation Agent:
   - Function: extract_citations(answer: str, chunks: List[Chunk]) -> List[Citation]
   - Identifies which chunks were actually used
   - Formats as: [filename, page_number]

6. File Storage
   - Local filesystem for development
   - S3-compatible storage for production
   - PDFs stored in: /data/documents/{user_id}/{document_id}.pdf

FRONTEND STACK:

1. Framework
   - Next.js 14 with App Router
   - TypeScript 5+ in strict mode
   - React Server Components where possible

2. Pages (app/ directory structure)
   /app
     /login/page.tsx            - JWT authentication
     /dashboard/page.tsx        - Document library
     /query/page.tsx            - Q&A interface
     /history/page.tsx          - Query history
     /admin/page.tsx            - Usage dashboard
     /api
       /auth/login/route.ts     - Auth endpoint
       /auth/refresh/route.ts   - Token refresh

3. Components (shadcn/ui)
   - DocumentUploader: Drag-drop with react-dropzone
   - ProcessingStatus: Progress indicator with steps
   - AgentActivityPanel: Real-time agent status display
   - QueryInterface: Question input with streaming response
   - CitationList: Expandable citations with source preview
   - HistoryList: Paginated query history

4. State Management
   - TanStack Query for server state
   - Zustand for client state (user, auth tokens)
   - WebSocket for real-time agent updates

5. Styling
   - Tailwind CSS
   - shadcn/ui theme system
   - Dark mode support

API INTEGRATION:

1. Endpoints
   POST   /auth/login              - Get JWT token
   POST   /auth/refresh            - Refresh token
   
   POST   /documents               - Upload document
   GET    /documents               - List user documents
   GET    /documents/{id}          - Get document details
   DELETE /documents/{id}          - Delete document
   POST   /documents/{id}/reprocess - Retry failed processing
   
   POST   /queries                 - Ask question
   GET    /queries                 - List query history
   GET    /queries/{id}            - Get specific query
   
   GET    /admin/usage             - Get usage stats
   GET    /admin/documents         - List all documents

2. WebSocket
   - ws://localhost:8000/ws/{user_id}
   - Events:
     * document_processing: {status: "extracting" | "embedding" | "complete"}
     * agent_activity: {agent: "retrieval" | "synthesis" | "citation", status: "working" | "complete"}
     * query_streaming: {token: str} - streamed answer tokens

DEPLOYMENT:

1. Docker Setup
   - docker-compose.yml with services:
     * api (FastAPI)
     * db (PostgreSQL with pgvector)
     * redis (Celery broker)
     * worker (Celery worker)
     * frontend (Next.js)

2. Development
   - Hot reload for both frontend and backend
   - Shared volume for document storage
   - Environment variables in .env file

3. Production Considerations
   - Use connection pooling (SQLAlchemy)
   - Enable CORS with specific origins
   - Rate limiting with slowapi
   - Request validation with size limits
   - Logging with structlog

TESTING STRATEGY:

1. Backend Tests (pytest)
   - Unit tests:
     * Model validation with Pydantic
     * Service layer functions
     * Agent logic (mocked LLM calls)
   - Integration tests:
     * API endpoints with TestClient
     * Database operations with test DB
     * Celery tasks with test broker
   - E2E tests:
     * Full document processing flow
     * Complete query workflow

2. Frontend Tests
   - Vitest for unit tests:
     * Component rendering
     * State management logic
     * Utility functions
   - React Testing Library:
     * User interactions
     * API integration (with MSW)
   - Playwright for E2E:
     * Login flow
     * Document upload
     * Query submission

FILE STRUCTURE:

backend/
  app/
    models/          # SQLModel models
    schemas/         # Pydantic schemas
    agents/          # Agent implementations
    services/        # Business logic
    api/             # Route handlers
    tasks/           # Celery tasks
    core/            # Config, security
  tests/
  alembic/           # Migrations
  requirements.txt

frontend/
  app/               # Next.js App Router pages
  components/        # React components
  lib/               # Utilities
  hooks/             # Custom React hooks
  types/             # TypeScript types
  tests/
  package.json

docker-compose.yml
.env.example
README.md
```

**What This Does:**
- Creates `.specify/specs/001-ragassist/plan.md`
- Creates `.specify/specs/001-ragassist/data-model.md`
- Creates `.specify/specs/001-ragassist/research.md`
- Creates `.specify/specs/001-ragassist/contracts/api-spec.json`

**Additional Research:**
```
I want you to research:
1. Latest OpenAI Agents SDK streaming patterns
2. pgvector performance optimization for our scale
3. FastAPI WebSocket best practices for real-time updates
4. Next.js 14 App Router authentication patterns
5. Celery task monitoring and error handling

For each, spawn parallel research tasks and update research.md
```

**Audit the Plan:**
```
Audit the implementation plan:
1. Check if any components are over-engineered
2. Verify all dependencies are clear
3. Ensure compliance with our constitution
4. Look for missing error handling
5. Confirm test strategy is comprehensive

Update plan.md with any refinements needed.
```

---

### Step 6: Generate Task Breakdown (3 minutes)

```
/speckit.tasks
```

**What This Does:**
- Creates `.specify/specs/001-ragassist/tasks.md`
- Breaks plan into ordered, executable tasks
- Marks parallel tasks with `[P]`
- Includes file paths for each task

**Expected Output Structure:**
```markdown
## Phase 1: Database & Models (Story 1 Foundation)

1. [Sequential] Create SQLModel models in app/models/user.py
2. [Sequential] Create SQLModel models in app/models/document.py
3. [Sequential] Create SQLModel models in app/models/chunk.py
4. [P] Create Pydantic schemas in app/schemas/document.py
5. [P] Write tests for models

## Phase 2: Document Upload API (Story 1)

6. [Sequential] Create POST /documents endpoint
7. [P] Add file validation middleware
8. [P] Write integration tests for upload

... (continues for all features)
```

---

### Step 7: Implement Everything (10-15 minutes)

```
/speckit.implement
```

**What Happens:**
- Agent reads tasks.md
- Executes each task in order
- Creates files and writes code
- Runs tests (if TDD was specified)
- Handles dependencies
- Provides progress updates

**You'll see:**
```
✓ Task 1/45: Created user model
✓ Task 2/45: Created document model
✓ Task 3/45: Created chunk model
...
```

**Monitor for:**
- File creation confirmations
- Test execution results
- Any error messages

---

### Step 8: Post-Implementation Testing (5 minutes)

```bash
# Test backend
cd backend
python -m pytest

# Run API server
uvicorn app.main:app --reload

# In another terminal, test frontend
cd frontend
npm run dev

# Open browser
open http://localhost:3000
```

**Manual Testing Checklist:**
- [ ] Can register/login
- [ ] Can upload PDF document
- [ ] Can see processing progress
- [ ] Can ask question about document
- [ ] Can see agent activity in real-time
- [ ] Can click citations
- [ ] Can view query history

**If Errors Occur:**
Copy error messages back to Claude Code:
```
I'm seeing this error when uploading a document:
[Paste error here]

Please fix this issue.
```

Agent will diagnose and fix the problem.

---

## 🎓 What You Learned

### Spec-Driven Development Workflow
1. ✅ Constitution sets project-wide principles
2. ✅ Specification defines WHAT without HOW
3. ✅ Clarification fills knowledge gaps early
4. ✅ Planning defines technical architecture
5. ✅ Tasks break work into executable steps
6. ✅ Implementation is systematic and traceable

### Key Takeaways
- **Specifications are executable** - They generate working code
- **Multi-step refinement** - Better than one-shot prompts
- **AI does the heavy lifting** - You focus on intent
- **Structured approach** - Reduces bugs and rework
- **Production-ready** - Not just prototypes

### Skills Developed
- Writing effective constitutions
- Creating detailed specifications
- Working with AI agents collaboratively
- System architecture planning
- Managing multi-phase projects

---

## 🚀 Next Steps

### Extend Your Project
1. **Add file types**: Support DOCX, TXT, Markdown
2. **Multiple models**: Let users choose embedding models
3. **Collaboration**: Share documents with team members
4. **Analytics**: Track which documents are queried most
5. **Fine-tuning**: Improve retrieval with user feedback

### Try Different Patterns
```bash
# LangGraph version
specify init rag-langgraph --ai claude
# Then specify with LangGraph state machines

# CrewAI version
specify init rag-crewai --ai claude
# Then specify with collaborative agents

# n8n integration
specify init rag-n8n --ai claude
# Then specify with workflow orchestration
```

### Build Something New
Choose a project relevant to your work:
- Agentic code review system
- Multi-agent research assistant
- Automated testing framework
- Documentation generator
- Customer support automation

---

## 📚 Resources

- [Full Mastery Guide](./spec-kit-mastery-guide.md)
- [Quick Start Cheat Sheet](./spec-kit-quick-start.md)
- [Official Spec-Kit Repo](https://github.com/github/spec-kit)
- [OpenAI Agents SDK Docs](https://platform.openai.com/docs/agents)
- [FastAPI Docs](https://fastapi.tiangolo.com/)
- [Next.js App Router](https://nextjs.org/docs/app)

---

## 🎯 Quiz Yourself

When you're ready to test your understanding, tell me and I'll create a comprehensive quiz covering:
- Core concepts
- Workflow steps
- Best practices
- Troubleshooting
- Real-world scenarios

**You've just built a production-grade RAG system using Spec-Driven Development!** 🎉
