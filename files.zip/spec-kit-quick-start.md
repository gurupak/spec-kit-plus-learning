# Spec-Kit Quick Start Cheat Sheet

## 🚀 Installation (Choose One Method)

### Method 1: Global Installation (Recommended)
```bash
# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install spec-kit globally
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# Verify installation
specify check
```

### Method 2: Direct Execution (No Installation)
```bash
# Run without installing
uvx --from git+https://github.com/github/spec-kit.git specify init my-project
```

---

## 📝 Starting a New Project

### Basic Initialization
```bash
# Create new project
specify init my-ai-project

# With specific AI agent (Claude Code recommended)
specify init my-ai-project --ai claude

# Alternative agents
specify init my-ai-project --ai cursor-agent    # Cursor
specify init my-ai-project --ai windsurf        # Windsurf
specify init my-ai-project --ai gemini          # Gemini CLI
```

### Initialize in Existing Directory
```bash
# In current directory
specify init . --ai claude

# Or use --here flag
specify init --here --ai claude

# Force merge (skip confirmation)
specify init . --force --ai claude
```

### Special Options
```bash
# Skip git initialization
specify init my-project --ai claude --no-git

# Debug mode (troubleshooting)
specify init my-project --ai claude --debug

# Corporate environment (with GitHub token)
specify init my-project --ai claude --github-token ghp_your_token

# PowerShell scripts (Windows)
specify init my-project --ai claude --script ps
```

---

## 🎯 The 6-Step Workflow (In Your AI Agent)

After running `claude` or your chosen agent:

### 1. Constitution (Define Principles)
```
/speckit.constitution Create principles for [your project type]:
- Code quality standards
- Testing requirements  
- Architecture patterns
- Performance goals
- Security requirements
```

**Example for AI Projects:**
```
/speckit.constitution Create principles for an agentic AI system:
- Use FastAPI with SQLModel for backend
- Next.js App Router with middleware for auth
- All LLM calls must have retry logic
- 80% test coverage minimum
- Agent response time <2s (95th percentile)
- Structured logging for all agent decisions
```

### 2. Specify (Define Requirements)
```
/speckit.specify [Describe WHAT you want to build and WHY]
```

**Example:**
```
/speckit.specify Build a RAG system called "SmartDocs":
- Users upload PDFs to workspace
- System chunks and generates embeddings
- Natural language queries trigger multi-agent workflow:
  * Retrieval Agent: Finds relevant chunks
  * Synthesis Agent: Creates coherent response
  * Verification Agent: Fact-checks sources
- Support OpenAI and Cohere embeddings
- Track query history and agent decisions
```

### 3. Clarify (Fill Gaps)
```
/speckit.clarify
```

Agent will ask questions. Answer them, then validate:
```
Read the review and acceptance checklist, and check off each item if the feature spec meets the criteria.
```

### 4. Plan (Technical Architecture)
```
/speckit.plan [Your tech stack and architecture]
```

**Example:**
```
/speckit.plan Architecture:

BACKEND:
- FastAPI with SQLModel
- PostgreSQL with pgvector
- Celery + Redis for async tasks
- OpenAI Agents SDK for orchestration

FRONTEND:
- Next.js 14 App Router
- shadcn/ui components
- TanStack Query for data fetching
- WebSocket for real-time updates

AI:
- OpenAI GPT-4 for synthesis
- text-embedding-3-large for embeddings
- LangGraph for agent coordination
```

Then research and audit:
```
Research the latest best practices for:
- OpenAI Agents SDK streaming
- FastAPI WebSocket patterns
- Next.js App Router auth

Then audit the plan for over-engineering and missing pieces.
```

### 5. Tasks (Break Down Work)
```
/speckit.tasks
```

This generates ordered, executable tasks in `tasks.md`

### 6. Implement (Execute)
```
/speckit.implement
```

Agent executes all tasks. Monitor progress and fix any errors.

---

## 🔧 Common Starting Patterns

### For OpenAI Agents SDK Project
```bash
# Initialize
specify init openai-assistant --ai claude

# In agent:
/speckit.constitution OpenAI Agents SDK principles:
- Use streaming for all responses
- Function calling for external APIs
- Assistant API with vector stores
- Rate limit handling
- Structured outputs with Pydantic

/speckit.specify Build a customer support assistant using OpenAI Assistant API...
```

### For LangGraph Multi-Agent System
```bash
# Initialize
specify init langgraph-agents --ai claude

# In agent:
/speckit.constitution LangGraph principles:
- StateGraph for all workflows
- Checkpointing for resumability
- Conditional edges for routing
- Subgraphs for complex logic

/speckit.specify Build a research automation system with LangGraph...
```

### For Next.js + FastAPI Full Stack
```bash
# Initialize
specify init fullstack-app --ai claude

# In agent:
/speckit.constitution Full-stack principles:
- Next.js App Router with middleware
- FastAPI with async/await
- SQLModel for database models
- shadcn/ui for components
- TypeScript strict mode
- Comprehensive API tests

/speckit.specify Build a SaaS application with...
```

---

## 🛠️ Maintenance Commands

### Upgrade Spec-Kit
```bash
uv tool install specify-cli --force --from git+https://github.com/github/spec-kit.git
```

### Check System Setup
```bash
specify check
```

### List Installed UV Tools
```bash
uv tool list
```

### Uninstall Spec-Kit
```bash
uv tool uninstall specify-cli
```

---

## 🐛 Quick Troubleshooting

### Commands Not Showing in Agent
```bash
# Check if CLAUDE.md exists
ls -la CLAUDE.md

# Re-initialize with force
specify init . --force --ai claude

# Verify setup
specify check
```

### For Non-Git Projects
```bash
# Set feature name before planning
export SPECIFY_FEATURE=001-my-feature

# Then use normal workflow
/speckit.plan
/speckit.tasks
/speckit.implement
```

### Git Authentication (Linux)
```bash
wget https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.6.1/gcm-linux_amd64.2.6.1.deb
sudo dpkg -i gcm-linux_amd64.2.6.1.deb
git config --global credential.helper manager
```

---

## 📚 All Available Slash Commands

| Command | Purpose |
|---------|---------|
| `/speckit.constitution` | Define project principles |
| `/speckit.specify` | Create requirements |
| `/speckit.clarify` | Structured Q&A |
| `/speckit.plan` | Technical architecture |
| `/speckit.tasks` | Generate task breakdown |
| `/speckit.implement` | Execute implementation |
| `/speckit.analyze` | Cross-artifact analysis |
| `/speckit.checklist` | Quality validation |

---

## 🎯 Your First 15 Minutes

```bash
# 1. Install (2 min)
curl -LsSf https://astral.sh/uv/install.sh | sh
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# 2. Create project (1 min)
specify init my-first-spec-project --ai claude
cd my-first-spec-project

# 3. Launch agent (1 min)
claude

# 4. Define principles (2 min)
/speckit.constitution Create principles focused on simplicity and clean code

# 5. Specify what to build (3 min)
/speckit.specify Build a simple task tracker with:
- Add, complete, delete tasks
- Filter by status (all, active, completed)
- Persist to local storage

# 6. Clarify (2 min)
/speckit.clarify
[Answer questions]

# 7. Plan (2 min)
/speckit.plan Use vanilla JavaScript with HTML/CSS, localStorage for persistence

# 8. Generate tasks (1 min)
/speckit.tasks

# 9. Implement (1 min to start)
/speckit.implement
```

**You're now running Spec-Driven Development!** 🎉

---

## 💡 Pro Tips

1. **Start simple**: Your first project should be small (CRUD app)
2. **Be specific in /speckit.specify**: More detail = better results
3. **Always run /speckit.clarify**: Catches ambiguities early
4. **Research in /speckit.plan**: For rapidly changing tech (AI SDKs, frameworks)
5. **Audit before /speckit.implement**: Check for over-engineering
6. **Test after implementation**: Copy errors back to agent for fixes

---

## 🔗 Resources

- [Full Learning Guide](./spec-kit-mastery-guide.md)
- [Official Repo](https://github.com/github/spec-kit)
- [Video Tutorial](https://www.youtube.com/watch?v=a9eR1xsfvHg)
- [Open Issues](https://github.com/github/spec-kit/issues)

---

**Ready to master spec-kit? Start with this cheat sheet, then dive into the full guide!**
