# Complete Spec-Driven Development Learning Hub 🚀

> **Master Both Spec-Kit & Spec-Kit-Plus for Building Production AI Applications**

The ultimate learning resource for **Spec-Driven Development** and **Spec-driven Vibe-coding**. Whether you're building general applications with GitHub's spec-kit or enterprise multi-agent AI systems with Panaversity's spec-kit-plus, this hub has everything you need.

[![GitHub](https://img.shields.io/badge/GitHub-spec--kit-blue?logo=github)](https://github.com/github/spec-kit)
[![PyPI](https://img.shields.io/badge/PyPI-specifyplus-blue)](https://pypi.org/project/specifyplus/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 🎯 What is Spec-Driven Development?

**The Paradigm Shift:**

For decades, code has been king — specifications were just scaffolding we discarded once coding began. Spec-Driven Development changes this: **specifications become executable**, directly generating working implementations.

### Traditional Development
```
Write code → Fix bugs → Refactor → Hope it works → Repeat ♾️
```

### Spec-Driven Development
```
Define WHAT → AI generates HOW → Structured implementation → Predictable outcomes ✅
```

### Spec-driven Vibe-coding (spec-kit-plus)
```
Conversational generation + Governance = Fast + Production-ready 🚀
```

---

## 📚 Choose Your Learning Path

This repository contains **two complete learning tracks**:

### 🔵 Track 1: GitHub's Spec-Kit (Original)
**For general application development**

Perfect for:
- Web applications (any framework)
- Mobile apps
- Desktop applications
- Framework-agnostic projects
- Learning the fundamentals
- Official GitHub methodology

**Materials:**
- [Spec-Kit Mastery Guide](./spec-kit-mastery-guide.md) - Complete 13-part guide
- [Quick Start Cheat Sheet](./spec-kit-quick-start.md) - Essential commands
- [Hands-On Tutorial](./spec-kit-hands-on-tutorial.md) - Build RAG system

### 🟣 Track 2: Panaversity's Spec-Kit-Plus (Enhanced)
**For production multi-agent AI systems**

Perfect for:
- Enterprise multi-agent systems
- OpenAI Agents SDK, LangGraph, CrewAI
- Kubernetes + Dapr + Ray deployment
- Production AI at scale (100s of users)
- ADR & PHR tracking
- Cloud-native infrastructure

**Materials:**
- [Spec-Kit-Plus Mastery Guide](./spec-kit-plus-mastery-guide.md) - Complete 11-part guide
- [Quick Start Cheat Sheet](./spec-kit-plus-quick-start.md) - Essential commands
- [Hands-On Tutorial](./spec-kit-plus-hands-on-tutorial.md) - Build production RAG

---

## 🆚 Spec-Kit vs Spec-Kit-Plus: Which One?

### Quick Comparison

| Feature | GitHub Spec-Kit | Panaversity Spec-Kit-Plus |
|---------|----------------|---------------------------|
| **Installation** | `uv tool install ... from git` | `pip install specifyplus` ✨ |
| **Command** | `specify` | `sp` or `specifyplus` |
| **Slash Commands** | `/speckit.constitution` | `/constitution` ✨ |
| **Philosophy** | Spec-Driven Development | Spec-driven Vibe-coding |
| **Best For** | Any application | Production AI systems 🤖 |
| **Tech Stack** | Framework-agnostic | Kubernetes, Dapr, Ray |
| **AI Focus** | General AI support | Multi-agent optimization |
| **ADR Tracking** | No | Yes ✅ |
| **PHR Tracking** | No | Yes ✅ |
| **Deployment** | Any platform | Cloud-native patterns |
| **Maturity** | Official, stable | Enhanced, production-focused |

### Decision Tree

```
Are you building multi-agent AI systems?
├─ No → Use spec-kit (Track 1)
│   └─ Better for general apps, simpler, official
│
└─ Yes → Are you deploying to production at scale?
    ├─ No → Use spec-kit (Track 1)
    │   └─ Simpler, less infrastructure complexity
    │
    └─ Yes → Use spec-kit-plus (Track 2) ✨
        └─ Built for Kubernetes, Dapr, Ray, enterprise patterns
```

### Use Spec-Kit (Track 1) If:
- ✅ Building web/mobile/desktop apps
- ✅ Want official GitHub methodology
- ✅ Prefer framework-agnostic approach
- ✅ Don't need production infrastructure patterns
- ✅ Learning Spec-Driven Development basics

### Use Spec-Kit-Plus (Track 2) If:
- ✅ Building **production multi-agent AI systems**
- ✅ Using **OpenAI Agents SDK, LangGraph, CrewAI**
- ✅ Deploying to **Kubernetes with Dapr & Ray**
- ✅ Need **ADR & PHR tracking**
- ✅ Targeting **enterprise scale** (100s of users)
- ✅ Want **cloud-native** patterns built-in

---

## 🚀 Quick Start

### For Spec-Kit (Track 1)

```bash
# Install
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# Create project
specify init my-app --ai claude

# Launch AI agent
cd my-app
claude

# Use workflow
/speckit.constitution
/speckit.specify
/speckit.clarify
/speckit.plan
/speckit.tasks
/speckit.implement
```

**[→ Full Quick Start Guide](./spec-kit-quick-start.md)**

### For Spec-Kit-Plus (Track 2)

```bash
# Install (much simpler!)
pip install specifyplus

# Create project
sp init my-ai-system --ai claude

# Launch AI agent
cd my-ai-system
claude

# Use workflow (simpler commands!)
/constitution
/specify
/clarify
/plan
/tasks
/analyze
/implement
```

**[→ Full Quick Start Guide](./spec-kit-plus-quick-start.md)**

---

## 📖 Complete Learning Materials

### Track 1: Spec-Kit Learning Materials

#### 1. 📘 [Spec-Kit Mastery Guide](./spec-kit-mastery-guide.md)
**13 parts, ~45 min read**

- Core concepts & philosophy
- Installation & setup
- The 6-step workflow
- Integration with OpenAI Agents SDK, LangGraph, CrewAI, n8n
- Best practices for FastAPI + Next.js
- Real-world project walkthrough
- Troubleshooting guide

#### 2. ⚡ [Spec-Kit Quick Start](./spec-kit-quick-start.md)
**5 min read - Essential reference**

- Installation commands
- Project initialization options
- All slash commands
- Common patterns
- Troubleshooting
- "Your First 15 Minutes"

#### 3. 🛠️ [Spec-Kit Hands-On Tutorial](./spec-kit-hands-on-tutorial.md)
**30-45 min hands-on**

- Build complete RAG system
- Multi-agent architecture
- FastAPI + Next.js + OpenAI Agents SDK
- Real-time updates
- Step-by-step implementation

### Track 2: Spec-Kit-Plus Learning Materials

#### 1. 📗 [Spec-Kit-Plus Mastery Guide](./spec-kit-plus-mastery-guide.md)
**11 parts, ~60 min read**

- Spec-driven Vibe-coding philosophy
- Production AI architecture
- OpenAI Agents SDK + MCP + Dapr + Ray
- ADR & PHR tracking
- Cloud-native patterns
- Enterprise deployment
- Advanced troubleshooting

#### 2. ⚡ [Spec-Kit-Plus Quick Start](./spec-kit-plus-quick-start.md)
**7 min read - Essential reference**

- PyPI installation
- `sp` command usage
- Simpler slash commands
- Production stack patterns
- Kubernetes troubleshooting
- "Your First 20 Minutes"

#### 3. 🛠️ [Spec-Kit-Plus Hands-On Tutorial](./spec-kit-plus-hands-on-tutorial.md)
**45-60 min hands-on**

- Build production 6-agent system
- Kubernetes + Dapr + Ray deployment
- OpenAI Agents SDK with MCP tools
- Horizontal scaling (500+ users)
- ADR & PHR creation
- Complete production stack

---

## 🎓 Recommended Learning Paths

### Path A: Complete Beginner
**Start with fundamentals, build to production**

1. **Week 1**: Read [Spec-Kit Mastery Guide](./spec-kit-mastery-guide.md) (Track 1)
2. **Week 2**: Do [Spec-Kit Tutorial](./spec-kit-hands-on-tutorial.md) - Build simple RAG
3. **Week 3**: Read [Spec-Kit-Plus Mastery Guide](./spec-kit-plus-mastery-guide.md) (Track 2)
4. **Week 4**: Do [Spec-Kit-Plus Tutorial](./spec-kit-plus-hands-on-tutorial.md) - Build production system

### Path B: Production AI Engineer
**Fast track to enterprise multi-agent systems**

1. **Day 1**: Skim [Spec-Kit Quick Start](./spec-kit-quick-start.md) (understand basics)
2. **Day 1**: Read [Spec-Kit-Plus Quick Start](./spec-kit-plus-quick-start.md) thoroughly
3. **Day 2-3**: Do [Spec-Kit-Plus Tutorial](./spec-kit-plus-hands-on-tutorial.md)
4. **Day 4+**: Build your production system, reference [Mastery Guide](./spec-kit-plus-mastery-guide.md)

### Path C: General App Developer
**Build any app with AI assistance**

1. **Day 1**: Read [Spec-Kit Quick Start](./spec-kit-quick-start.md)
2. **Day 2**: Do [Spec-Kit Tutorial](./spec-kit-hands-on-tutorial.md)
3. **Ongoing**: Use [Spec-Kit Mastery Guide](./spec-kit-mastery-guide.md) as reference

### Path D: Just-In-Time Learning
**Learn as you build**

1. Bookmark appropriate [Quick Start](./spec-kit-quick-start.md) or [Plus Quick Start](./spec-kit-plus-quick-start.md)
2. Initialize your real project
3. Reference [Mastery Guides](./spec-kit-mastery-guide.md) as needed
4. Do tutorials when you have time

---

## 🎯 Who This Is For

### Agentic AI Engineers
Perfect for those building:
- Multi-agent systems
- RAG applications
- Autonomous AI workflows
- LangChain/LangGraph applications
- CrewAI collaborative agents
- n8n AI integrations

**Recommended**: Start with Track 2 (Spec-Kit-Plus)

### Full-Stack Developers
Great for those using:
- Next.js + FastAPI
- React + Python
- Modern web frameworks
- REST APIs
- Database-driven apps

**Recommended**: Start with Track 1 (Spec-Kit)

### Solutions Architects
Ideal for designing:
- Scalable AI platforms
- Enterprise AI systems
- Cloud-native architectures
- Multi-tenant systems
- Microservices

**Recommended**: Learn both tracks

### Technical Leaders
Essential for:
- Evaluating methodologies
- Team adoption strategies
- Architecture decisions
- Technology selection
- Governance frameworks

**Recommended**: Read both Mastery Guides

---

## 🛠️ Prerequisites

### For Track 1 (Spec-Kit)
- Python 3.11+
- Git
- AI coding agent (Claude Code, Cursor, etc.)
- uv package manager

### For Track 2 (Spec-Kit-Plus)
**Additional requirements:**
- Docker
- Kubernetes (local or cloud)
- Helm 3.12+
- kubectl
- Basic K8s knowledge

### Recommended for Both
- Node.js 18+ (for Next.js projects)
- PostgreSQL (for database projects)
- OpenAI API key (for AI projects)
- Basic understanding of REST APIs

---

## 🌟 What You'll Learn

### Core Concepts (Both Tracks)
- Spec-Driven Development philosophy
- Constitution → Specify → Clarify → Plan → Tasks → Implement workflow
- Working with AI coding agents
- Writing effective specifications
- Systematic implementation
- Testing strategies

### Track 1 Specifics (Spec-Kit)
- Framework-agnostic development
- OpenAI Agents SDK integration
- LangGraph state machines
- CrewAI collaborative agents
- n8n workflow orchestration
- General web/app development

### Track 2 Specifics (Spec-Kit-Plus)
- **Spec-driven Vibe-coding** methodology
- **Production multi-agent** architectures
- **Kubernetes** deployment patterns
- **Dapr** for service mesh and actors
- **Ray** for distributed compute
- **MCP** (Model Context Protocol) tools
- **A2A** (Agent-to-Agent) messaging
- **ADR** (Architecture Decision Records)
- **PHR** (Prompt History Records)
- **OpenTelemetry** observability
- **Horizontal scaling** strategies
- **Multi-tenancy** patterns

---

## 📊 Real-World Examples

### Spec-Kit Examples (Track 1)

**1. RAG System with OpenAI Agents**
- Document upload and processing
- Multi-agent query handling
- Real-time progress updates
- FastAPI + Next.js
- **Tutorial**: [Spec-Kit Hands-On](./spec-kit-hands-on-tutorial.md)

**2. Customer Support Bot**
- Classifier, Resolution, Escalation agents
- LangGraph coordination
- Integration with CRM
- Conversation history

**3. Content Pipeline**
- Research, Write, Edit, Optimize agents
- CrewAI collaboration
- n8n orchestration
- Publishing workflow

### Spec-Kit-Plus Examples (Track 2)

**1. Enterprise RAG Platform**
- 6-agent architecture (production-grade)
- Kubernetes + Dapr + Ray
- 500+ concurrent users
- Multi-tenant isolation
- **Tutorial**: [Spec-Kit-Plus Hands-On](./spec-kit-plus-hands-on-tutorial.md)

**2. Research Automation System**
- Distributed agent coordination
- Dapr workflows
- Ray parallel processing
- ADR & PHR tracking

**3. Customer Intelligence Platform**
- Real-time data ingestion
- Agent-based analysis
- Kubernetes HPA scaling
- OpenTelemetry monitoring

---

## 🔧 Installation & Setup

### Spec-Kit (Track 1)

```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install spec-kit
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# Verify
specify check

# Create first project
specify init my-app --ai claude
```

### Spec-Kit-Plus (Track 2)

```bash
# Install (PyPI - much simpler!)
pip install specifyplus

# Or with uv
uv tool install specifyplus

# Verify
sp check

# Create first project
sp init my-ai-system --ai claude
```

---

## 📝 Command Reference

### Spec-Kit Commands

```bash
# Installation
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git

# Project management
specify init <project>              # Create new project
specify init <project> --ai claude  # With specific AI agent
specify check                       # Verify installation

# In AI agent (slash commands)
/speckit.constitution  # Define project principles
/speckit.specify       # Requirements & user stories
/speckit.clarify       # Fill knowledge gaps
/speckit.plan          # Technical architecture
/speckit.tasks         # Task breakdown
/speckit.implement     # Execute implementation
/speckit.analyze       # Consistency analysis
/speckit.checklist     # Quality validation
```

### Spec-Kit-Plus Commands

```bash
# Installation
pip install specifyplus

# Project management
sp init <project>              # Create new project
sp init <project> --ai claude  # With specific AI agent
sp check                       # Verify installation

# In AI agent (slash commands - simpler!)
/constitution  # Define governance
/specify       # Requirements & user stories
/clarify       # Fill knowledge gaps (REQUIRED before /plan)
/plan          # Technical architecture
/tasks         # Task breakdown
/analyze       # Cross-artifact validation
/implement     # Execute implementation
```

**Note the difference**: Spec-kit-plus uses simpler commands (`/plan` vs `/speckit.plan`)

---

## 🤝 Contributing

We welcome contributions! Help us improve these materials:

### What We're Looking For
- Additional real-world examples
- Integration guides for more frameworks
- Troubleshooting tips from production experience
- Translations to other languages
- Video tutorials
- Case studies from your projects
- Bug fixes and improvements

### How to Contribute

1. **Fork** this repository
2. **Create** a branch: `git checkout -b feature/my-improvement`
3. **Make** your changes
4. **Test** thoroughly
5. **Submit** a Pull Request

### Contribution Ideas
- More integration examples (Anthropic SDK, Vercel AI SDK)
- Advanced patterns (multi-region, disaster recovery)
- Cost optimization strategies
- Security best practices
- Performance tuning guides
- Alternative deployment strategies

---

## 📄 License

This learning material is provided under the **MIT License**. See [LICENSE](LICENSE) file for details.

### Related Projects
- [GitHub Spec-Kit](https://github.com/github/spec-kit) - MIT License
- [Panaversity Spec-Kit-Plus](https://github.com/panaversity/spec-kit-plus) - MIT License

---

## 🙏 Acknowledgements

### Special Thanks
- **GitHub** for creating the original [Spec-Kit](https://github.com/github/spec-kit)
- **Panaversity** for the enhanced [Spec-Kit-Plus](https://github.com/panaversity/spec-kit-plus)
- **John Lam** ([@jflam](https://github.com/jflam)) for pioneering Spec-Driven Development
- **Anthropic** for Claude Code and advancing AI-assisted development
- **The AI Engineering Community** for continuous feedback and improvements

### Built On
- Spec-Driven Development methodology
- OpenAI Agents SDK
- LangChain & LangGraph
- CrewAI
- Dapr distributed systems
- Ray distributed computing
- Kubernetes cloud-native practices

---

## 📞 Support & Resources

### Official Documentation
- [Spec-Kit Repo](https://github.com/github/spec-kit)
- [Spec-Kit-Plus Repo](https://github.com/panaversity/spec-kit-plus)
- [OpenAI Agents SDK](https://platform.openai.com/docs/agents)
- [Dapr Documentation](https://docs.dapr.io/)
- [Ray Documentation](https://docs.ray.io/)

### Community
- Report bugs or ask questions via GitHub Issues
- Join AI engineering communities
- Share your projects and learnings

### Learning Resources
- [Video Overview](https://www.youtube.com/watch?v=a9eR1xsfvHg) (Spec-Kit)
- [Panaversity](https://panaversity.com/) (Spec-Kit-Plus)
- [MCP Protocol](https://modelcontextprotocol.io/)

---

## 🗺️ Repository Structure

```
/
├── README.md                              # This file - main hub
│
├── Track 1: Spec-Kit Materials
│   ├── spec-kit-mastery-guide.md         # Complete reference
│   ├── spec-kit-quick-start.md           # Quick commands
│   └── spec-kit-hands-on-tutorial.md     # Build RAG system
│
├── Track 2: Spec-Kit-Plus Materials
│   ├── spec-kit-plus-mastery-guide.md    # Production reference
│   ├── spec-kit-plus-quick-start.md      # Quick commands
│   └── spec-kit-plus-hands-on-tutorial.md # Build production system
│
└── LICENSE                                 # MIT License
```

---

## 🚀 Get Started Now

### For General Apps → Spec-Kit (Track 1)
```bash
pip install uv
uv tool install specify-cli --from git+https://github.com/github/spec-kit.git
specify init my-app --ai claude
```
**[→ Continue with Quick Start](./spec-kit-quick-start.md)**

### For Production AI → Spec-Kit-Plus (Track 2)
```bash
pip install specifyplus
sp init my-ai-system --ai claude
```
**[→ Continue with Quick Start](./spec-kit-plus-quick-start.md)**

### Not Sure? Start Here:
1. Read [Spec-Kit Mastery Guide](./spec-kit-mastery-guide.md) (fundamentals)
2. Do [Spec-Kit Tutorial](./spec-kit-hands-on-tutorial.md) (basic system)
3. Then decide if you need production features of spec-kit-plus

---

## 💡 Key Takeaways

### Why Spec-Driven Development?
1. **Specifications become executable** - Not just documentation
2. **AI does the heavy lifting** - You focus on WHAT, not HOW
3. **Structured approach** - Reduces bugs and rework
4. **Better documentation** - Natural byproduct of the process
5. **Team alignment** - Shared understanding of requirements

### Spec-Kit vs Spec-Kit-Plus
- **Spec-Kit**: Perfect for learning and general apps
- **Spec-Kit-Plus**: Built for production multi-agent AI systems
- **Both**: Share the same core philosophy
- **Choose based on**: Your use case and scale needs

### The Future
With AI writing code, developers focus on:
- 🎯 Strategic problem-solving
- 🏗️ System architecture
- 🔍 Root cause analysis
- ❓ Asking the right questions
- ⚖️ Technical governance

**Spec-Driven Development is how we build that future.**

---

## 📌 Quick Links

### Track 1: Spec-Kit
- 📘 [Mastery Guide](./spec-kit-mastery-guide.md)
- ⚡ [Quick Start](./spec-kit-quick-start.md)
- 🛠️ [Tutorial](./spec-kit-hands-on-tutorial.md)
- 🔗 [GitHub Repo](https://github.com/github/spec-kit)

### Track 2: Spec-Kit-Plus
- 📗 [Mastery Guide](./spec-kit-plus-mastery-guide.md)
- ⚡ [Quick Start](./spec-kit-plus-quick-start.md)
- 🛠️ [Tutorial](./spec-kit-plus-hands-on-tutorial.md)
- 🔗 [GitHub Repo](https://github.com/panaversity/spec-kit-plus)

---

## 🎯 Testing Your Knowledge

After completing the materials, you should be able to:

**Spec-Kit (Track 1):**
- [ ] Explain Spec-Driven Development philosophy
- [ ] Install and use spec-kit with `specify` commands
- [ ] Write effective constitutions and specifications
- [ ] Use all 6 slash commands correctly
- [ ] Build a multi-agent RAG system
- [ ] Integrate with OpenAI Agents SDK, LangGraph, CrewAI
- [ ] Debug common issues

**Spec-Kit-Plus (Track 2):**
- [ ] Explain Spec-driven Vibe-coding
- [ ] Install with `pip install specifyplus`
- [ ] Use simpler `sp` and `/constitution` commands
- [ ] Design production multi-agent architectures
- [ ] Deploy to Kubernetes with Dapr and Ray
- [ ] Create ADRs for architecture decisions
- [ ] Track prompts with PHRs
- [ ] Scale to 100+ concurrent users
- [ ] Troubleshoot K8s/Dapr/Ray issues

---

<div align="center">

## 🌟 Ready to Transform Your Development?

Choose your path and start building better systems with AI assistance.

**Track 1: General Apps** → [Spec-Kit Quick Start](./spec-kit-quick-start.md)  
**Track 2: Production AI** → [Spec-Kit-Plus Quick Start](./spec-kit-plus-quick-start.md)

---

**Built with ❤️ for the AI Engineering Community**

*From idea to production with Spec-Driven Development*

[⭐ Star Spec-Kit](https://github.com/github/spec-kit) · [⭐ Star Spec-Kit-Plus](https://github.com/panaversity/spec-kit-plus) · [🐛 Report Issue](https://github.com/github/spec-kit/issues) · [💡 Contribute](#-contributing)

---

**The future of software development is here. It's spec-driven.** 🚀

</div>
